
#!/usr/bin/env python3
import os, datetime, logging, json

CONFIG_PATH = "config.json"
with open(CONFIG_PATH) as f:
    config = json.load(f)

outdata_path = os.path.abspath(config['common']['outdataPath'])
os.makedirs(outdata_path, exist_ok=True)
os.chdir(outdata_path)

today = datetime.datetime.now(datetime.UTC).strftime("%y%m%d0000")
valid_files = [f for f in os.listdir(outdata_path) if f.startswith(today) and f.endswith(".grib2")]
valid_hours = {int(f[-7:-5]) for f in valid_files if f[-7:-5].isdigit()}

print(f"✅ GFS file prefix : {today}.")
print(f"✅ Now in data directory : {outdata_path}.")
print(f"✅ valid_hours : {valid_hours}.")
print(f"✅ missing : {[h for h in range(384) if h not in valid_hours]} hours.")
